/******************************************************************************

Author: Wenbo Chen
Version: 1.0
Target: Calculator application developed using Qt
Develop Environment: x86_windows_msvc2017 32bit

*******************************************************************************/

IMPORTNAT:
This application claims no right, it is a learning project from tutorial of the following link (https://www.youtube.com/watch?v=FhV1ZEVNK08&list=PLJ9GeMZoIma5UCFFehlPatmpBXmIqrVJE)

Double click on "Calculator.exe" to execute the application.